# OpenAlex live query audit

Run on 2 November 2026, Singapore time. API timestamps are recorded in UTC in the response files.

The supplied draft was read without modifying it. D and G2 were executed verbatim from its complete query strings. Other variants were reconstructed from G2 or the described changes; their exact query strings and API query objects are included. A–C were not reconstructed because the draft does not provide their complete original queries.

## Result counts

| Query | Draft count | Live count | Named records retrieved / 13 |
|---|---:|---:|---:|
| D: original one-sided proximity | 3103 | 3103 | 2 |
| E: misplaced topic clause | 3701 | 3701 | 9 |
| E: corrected topic clause | 5574 | 5574 | 10 |
| G1: broad unknown-country exception | 12985 | 12985 | 13 |
| G2: misplaced topic clause | 3891 | 3891 | 12 |
| G2: final query as printed | 5764 | 5764 | 13 |
| G2: tighter distances | 5734 | 5734 | 13 |
| Exploratory: no topic fallback; add unscreen* | Not in draft | 3892 | 13 |

## Named-record recovery

This is a diagnostic set of 13 named works extracted from the draft, deliberately enriched for failures. It is not the complete 130-study benchmark and is not a representative recall estimate.

| Work | D | E corrected | G2 | G2 tighter | Exploratory unscreen* |
|---|---|---|---|---|---|
| The role of tele-ophthalmology as part of a community health service to remote top end Northern Territory communities : cost-effectiveness study of diabetic retinopathy screening, monitoring and management (W102211962) | No | No | Yes | Yes | Yes |
| Rationale and Implementation of the SLICK Project (W1582532655) | No | Yes | Yes | Yes | Yes |
| Socioeconomic factors associated with visual impairment and ophthalmic care utilization in patients with type II diabetes (W1974257011) | No | Yes | Yes | Yes | Yes |
| Factors Associated With Regular Eye Examinations in People With Diabetes: Results From the Victorian Population Health Survey (W2069087339) | No | Yes | Yes | Yes | Yes |
| Unintended consequences of delisting routine eye exams on retinopathy screening for people with diabetes in Ontario, Canada (W2127888591) | No | Yes | Yes | Yes | Yes |
| Access to a local Digital Diabetic Retinopathy Screening Service (W2128326945) | Yes | Yes | Yes | Yes | Yes |
| Diabetic retinopathy screening: Study to determine risk factors for non-attendance (W2346489057) | No | No | Yes | Yes | Yes |
| Diabetes eye screening in the Wellington region of New Zealand: characteristics of the enrolled population (2002-2005). (W2405119914) | No | Yes | Yes | Yes | Yes |
| Inadequate screening for retinopathy among recent immigrants with type 2 diabetes despite universal health care: A population-based study (W2575340954) | No | Yes | Yes | Yes | Yes |
| Evaluation of the diabetic retinopathy remote screening pilot project among Quebec First Nations (W3213923128) | Yes | Yes | Yes | Yes | Yes |
| Perceived barriers and facilitators to attending diabetic eye screening appointments during the COVID-19 pandemic (W4223469416) | No | No | Yes | Yes | Yes |
| Prevalence and predictors for being unscreened for diabetic retinopathy: a population-based study over a decade (W4280598166) | No | Yes | Yes | Yes | Yes |
| Understanding barriers to diabetes eye screening in a large rural general practice: an audit of patients not reached by screening services (W4297977795) | No | Yes | Yes | Yes | Yes |

## Verified mechanism and correction

- The misplaced topic clause validates (validation.valid=true), but its compiled query treats field-like tokens as text. Executed alone it returns zero works.
- Removing the inert branch gives the same E count, 3,701. Correcting the topic branch raises E to 5,574 and recovers Felfeli among the diagnostic studies.
- Felfeli (W4280598166) DOES match diabetic/retinopathy within four words. It does NOT match screen* or the complete screening block of D. Its title contains unscreened. Its absence from D therefore cannot be attributed to failure of that proximity condition.
- Adding unscreen* to the original screening block, keeping both proximity branches and G2 geography, and omitting the topic fallback returns 3,892 works. All 13 named studies match. This is exploratory, tuned against an observed miss, and is not an independent validation.
- G2 recovers Lewis, Sachdeva and Ho, which corrected E misses. The tighter-distance G2 also retrieves all 13 named works.

## Additional counts

| Test | Live result |
|---|---:|
| Elsevier 2024–2025 articles without OpenAlex abstracts | 1183246 |
| Same set with a PMID | 308942 |
| AMR phrase in title/abstract, abstract-less Elsevier subset | 1330 |
| AMR phrase using about, same subset | 1902 |

Publisher and open-access grouped counts are retained in articles_by_publisher.json and articles_by_OA.json. These reproduce the displayed rounded abstract-availability percentages. A PMID does not establish that a PubMed abstract exists.

## Limits

- The complete 130 OpenAlex benchmark IDs were not supplied. Neither 128/128 nor 130/130 has been independently verified.
- Historical 2024/2025 results were not rerun and cannot be reconstructed from current index data alone.
- Named-study checks append an AND restriction for the 13 IDs to the API-returned canonical OQO. They are not intersections with downloaded full result sets.
- No complete result-set exports were downloaded; total counts come from API metadata.
- Fulltext holdings counts, historic A–C queries, and PubMed abstract availability were not tested.
- JSON files include exploratory validation errors as well as successful responses, to preserve an audit trail. Failed ID-filter trials are superseded by successful ids.openalex tests.
- No API key is included in this archive.
