# OpenAlex complete benchmark recall audit

Live verification on 2 November 2026, Singapore time. All request timestamps are saved in UTC.

## Benchmark provenance

The authors deposited UtilityOpenAlexDES-version for OSF.xlsx at https://osf.io/2nrzy, within https://osf.io/sndr3/. The Stansfield paper links that OSF project in its Data Availability Statement: https://pmc.ncbi.nlm.nih.gov/articles/PMC12302543/.

The downloaded workbook SHA256 matches the OSF file metadata: d72c8258f1454f798ce0e0120a390004cac923512e92d02e0f97528ffe79f4ec.

The sheet Includes in DES map = 133 contains 133 records: 131 original records and two added records (Briand-Racine 2013 and Hirji 2014). There are 130 distinct OpenAlex IDs: 128 original studies plus the two additions. Hayden 2012, Kumar 2022 and Turner 2004 have no OpenAlex ID in that source and remain outside this fixed benchmark. Their present-day coverage was not investigated.

The public interactive map at https://eppi.ioe.ac.uk/cms/Portals/35/Maps/TaSP.html contains 134 reference records. Its additional record relative to the deposited spreadsheet is Larizza 2013, EPPI ID 93509442. It was not silently added to this benchmark.

## Identifier reconciliation

The source ID W4210587850 for Lindenmeyer 2014 returns HTTP 404. PMID 25071061 resolves to W2140408413, with matching title and publication year, DOI 10.3399/bjgp14x680965. Using the obsolete ID creates an artificial miss in every strategy.

Three pairs of source rows have swapped OpenAlex IDs, verified against their PMIDs and titles: Prothero 2022 (interview versus survey), Riordan (acceptability versus intervention feasibility), and Ting 2011 (optometrists versus GPs). These swaps do not change the set of 130 IDs but matter for the per-study matrix. Source IDs are preserved alongside verified IDs; all seven row changes are recorded in id_corrections.json.

## Live recall

| Strategy | Results | Original indexed set | Expanded indexed set | Recall over 130 |
|---|---:|---:|---:|---:|
| D: one-sided proximity | 3,103 | 112/128 | 114/130 | 87.7% |
| E: misplaced topic clause | 3,701 | 124/128 | 126/130 | 96.9% |
| E: corrected topic fallback | 5,574 | 125/128 | 127/130 | 97.7% |
| G1: broad country-unknown exception | 12,985 | 128/128 | 130/130 | 100.0% |
| G2: misplaced topic clause | 3,891 | 127/128 | 129/130 | 99.2% |
| G2: final corrected query | 5,764 | 128/128 | 130/130 | 100.0% |
| G2: tighter proximity distances | 5,734 | 128/128 | 130/130 | 100.0% |
| No topic fallback; add unscreen* | 3,892 | 128/128 | 130/130 | 100.0% |

D and final G2 were taken verbatim from the supplied draft. E, G1, misplaced-topic and tighter-distance variants were reconstructed from its stated modifications. A–C cannot be verified from the incomplete query descriptions and were not tested.

The queries were rerun unrestricted to obtain result counts and with an added AND filter for the complete reconciled 130-ID benchmark to measure recall. The per-study file also retains the three original records outside that indexed benchmark.

## Findings

- The draft recall figures are reproduced after resolving the obsolete Lindenmeyer ID.
- E with corrected topic fallback misses Ho 2006, Lewis 2022 and Sachdeva 2012. Misplaced-topic E also misses Felfeli 2023.
- G2 with misplaced topic fallback misses only Felfeli 2023.
- G1, corrected G2, tighter G2, and the exploratory unscreen* query recover all 130 known indexed studies.
- The exploratory query retrieves 3,892 records: 1,872 fewer (32.5%) than G2, and 82.1% fewer than the historical July 2024 volume of 21,747. These are result-count comparisons, not measured screening-time savings or controlled estimates of OQL effects.
- Recovery of 130/130 indexed benchmark studies corresponds to 128/131 (97.7%) of the original benchmark and 130/133 (97.7%) of the expanded benchmark, counting the three out-of-benchmark source records as unrecovered.
- The exploratory query is tuned against an observed miss. Full benchmark recovery does not establish recall on unseen eligible studies or overall screening precision.

## Query access

benchmark_130_verified_ids.txt is a copyable list of the current 130 IDs. benchmark_130_ids.txt preserves the source ID list. per_study_retrieval.csv has all 133 source rows and eight strategy outcomes. strategy_queries.txt contains the complete unrestricted queries. JSON responses preserve query objects, counts, retrieved benchmark IDs and timestamps.

## Independent check against unrestricted results

All 130 verified benchmark IDs occur in the downloaded pages of the exploratory query without an ID filter. The API reported 3,892 results. Twenty numbered pages returned 3,892 rows with 3,891 distinct IDs because W2293428309 occurred twice. The export establishes presence of every benchmark study, although it does not account for every unique result in the unrestricted set.
